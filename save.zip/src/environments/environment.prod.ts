export const environment = {
  production: true,
  firebase: {
      apiKey: "AIzaSyAEck5ihlE1b0fLXMqWK3RikZaZVfizCZ8",
      authDomain: "projetmobile-3cbad.firebaseapp.com",
      databaseURL: "https://projetmobile-3cbad.firebaseio.com",
      projectId: "projetmobile-3cbad",
      storageBucket: "projetmobile-3cbad.appspot.com",
      messagingSenderId: "97993183729",
      appId: "1:97993183729:web:dd92239950d6a0641f3450",
      measurementId: "G-T55VY4BDL3"
  }
};
